# WordTown

☉ Programming Language: C# <br>
☉ Framework: WinForms <br>
☉ Operating System: Windows <br>
☉ Database: Microsoft Access <br>

<i>With "WordTown", you can test your own English and learn new Turkish words all the time.</i>

## WordTown Start Menu

![WordTownStartGame](https://user-images.githubusercontent.com/65850970/129720267-1a02db63-746c-4c96-a3c5-9ac8a655ae05.PNG)

## WordTown In Game

![WordTownInGame](https://user-images.githubusercontent.com/65850970/129720289-44fdc369-b625-4f57-8df5-729d86f24684.PNG)

## WordTown Statistics MessageBox

![WordTownGameFinish](https://user-images.githubusercontent.com/65850970/129720315-a8ef0bf8-ac3d-47e2-8fbf-cc38ae11779b.PNG)
